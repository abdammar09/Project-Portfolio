import random
import math
import pandas as pd
import problem_bank_helpers as pbh

def imports(data):
    import random
    import math
    import pandas as pd
    import problem_bank_helpers as pbh
    
def generate(data):
    data2 = pbh.create_data2()
    
    data2["params"]["vars"]["title"] = "Washing Machine Mechanics"
    
    # define bounds of the variables
    m = random.randint(0,4)
    r = random.randint(1,4)
    
    # store the variables in the dictionary "params"
    data2["params"]["m"] = m
    data2["params"]["r"] = r
    
    # define correct answers
    
    data2["correct_answers"]["part1_ans"] = math.sqrt(9.81 * r)
    
    # Update the data object with a new dict
    data.update(data2)
    
def prepare(data):
    pass
    
def parse(data):
    pass
    
def grade(data):
    pass
    
