---
title: Washing Machine Mechanics
topic: Plane Curvilinear Kinetics
author: Ammar Zavahir
source: original
template_version: 1.3
attribution: standard
partialCredit: true
singleVariant: false
outcomes:
- 6.12.1.1
- 6.12.2.0
difficulty:
- undefined
randomization:
- undefined
taxonomy:
- undefined
span:
- undefined
length:
- undefined
tags:
- APSC 181
- A.Z
assets:
server: 
    imports: |
        import random
        import math
        import pandas as pd
        import problem_bank_helpers as pbh
    generate: |
        data2 = pbh.create_data2()

        data2["params"]["vars"]["title"] = "Washing Machine Mechanics"
        
        # define bounds of the variables
        m = random.randint(0,4)
        r = random.randint(1,4)

        # store the variables in the dictionary "params"
        data2["params"]["m"] = m
        data2["params"]["r"] = r
        
        # define correct answers
        
        data2["correct_answers"]["part1_ans"] = math.sqrt(9.81 * r)
        
        # Update the data object with a new dict
        data.update(data2)
    prepare: |
        pass
    parse: |
        pass
    grade: |
        pass
part1:
  type: number-input
  pl-customizations:
    rtol: 0.05
    weight: 1
    allow-blank: true
    label: $v= $
    suffix: m/s
---
# {{ params.vars.title }}

A washing machine works by rotating the drum about a horizontal axis in a vertical plane. For thorough cleaning, detergent is sprayed from tiny holes in the surface of the drum.

## Question Text

Determine the minimum speed v for which the drum has to spin to ensure the clothes remain in contact with the drum for maximum detergent absorption. Treat the clothes as a single particle with mass, m = {{ params.m }}. The effective radius of the drum is r = {{ params.r }}. Assume the clothes do not slip relative to the drum anywhere along the circular motion.  

### Answer Section

Please enter in a numeric value in m/s.

## Rubric

This should be hidden from students until after the deadline.

## Solution

This should never be revealed to students.

## Comments

These are random comments associated with this question.
